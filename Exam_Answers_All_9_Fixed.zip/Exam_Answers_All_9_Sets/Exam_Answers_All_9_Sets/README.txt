ALL 9 SETS — QUESTION-WISE ANSWERS

Each SET-N folder contains one text file with the answers arranged question-by-question
and Part I / Part II / Part III.

Notes:
- Repository URLs and question wording are taken from the uploaded papers.
- Where the papers say a POM contains intentional errors but do not show the actual faulty
  POM, the answer gives the required corrected configuration rather than inventing hidden errors.
- Replace placeholders such as YOUR_USERNAME, YOUR_GITHUB_REPOSITORY_URL and
  com.example.Main with your actual values when required.
